# ISRAVN Hardstyle V.1 — JUCE VST3 source (v1 branding / prototype audio engine)

A real C++ JUCE project for a MIDI-playable hardstyle synth, intended for Windows + FL Studio.

## ISRAVN theme
Arctic night palette, cyan controls, frosted blue accents and ISRAVN branding. Audio engine is the same prototype as the earlier HARDCORE AI PRO project.

## Implemented
- 12-voice polyphonic synthesizer, 1–7 detuned saw/square oscillators per note
- ADSR, low-pass filter, pitch envelope, waveshaping distortion
- Stereo delay, reverb, output gain
- Ice-blue / midnight-blue editor with 14 automatable controls
- Offline natural-language *rule-based* preset generator; repeat click for variations
- Host state saving and recall
- VST3 and standalone build targets

## Build on Windows
1. Install Visual Studio 2022 (Desktop development with C++ workload), Git, and CMake 3.22+.
2. Open PowerShell in this folder.
3. Run:

```powershell
cmake -S . -B build -G "Visual Studio 17 2022" -A x64
cmake --build build --config Release --target IsravnHardstyleV1_VST3
```

The first configure downloads JUCE 8.0.10 from GitHub (requires internet). If successful, locate `ISRAVN Hardstyle V.1.vst3` under `build/IsravnHardstyleV1_artefacts/Release/VST3/` (a VST3 bundle folder on Windows).

4. Copy the **entire** `.vst3` bundle to `C:\Program Files\Common Files\VST3\` (administrator rights may be required).
5. In FL Studio: Options > Manage plugins > Find installed plugins. Load **ISRAVN Hardstyle V.1** as an instrument and play MIDI from the piano roll.

## AI scope
The current generator uses keyword matching and deterministic variation, **not a trained AI model**, and runs offline. To integrate a real LLM later, implement an asynchronous preset-description service that returns validated parameter values; apply changes on the message thread, never block the audio thread. Do not put API secrets inside a shipped plugin. A backend proxy or local model is recommended.

## Known limitations
This is an initial implementation and has not been compiled or tested against FL Studio in this environment. It does not yet include a wavetable editor, multiband processing, kick sample designer, preset browser, oversampling, or commercial-grade antialiasing. Its oscillators and effects are basic and may alias at high notes/distortion. Distortion and filtering are per voice, while delay/reverb are global. The pitch-envelope is exponential and note-on triggered.

## Safety / development notes
Test at low speaker volume initially; distortion can create sharp peaks. CPU cost scales with polyphony and unison. Parameters are changed by the GUI on the host/message thread; never invoke preset generation from the audio callback.

## Build without installing a compiler (GitHub Actions)
This repository includes `.github/workflows/build-windows-vst3.yml` to compile the Windows VST3 on a GitHub-hosted Windows runner.

1. Create a **private** GitHub repository (recommended) and upload **all contents** of this folder, including the hidden `.github` folder. GitHub's web uploader can upload a folder's contents; verify `.github/workflows/build-windows-vst3.yml` is present.
2. Open your repository's **Actions** tab, enable workflows if prompted, select **Build ISRAVN Windows VST3**, and click **Run workflow**.
3. Wait for the build job to finish successfully. Under the workflow run's **Artifacts**, download **ISRAVN-Hardstyle-V1-Windows-VST3**.
4. Extract the downloaded artifact ZIP, then extract the `ISRAVN_Hardstyle_V1_Windows_VST3.zip` inside it. The inner ZIP contains the compiled `.vst3` directory.
5. Copy the entire `.vst3` directory to `C:\Program Files\Common Files\VST3\` or run the included `INSTALL_WINDOWS.ps1` in PowerShell (may require administrator permissions).
6. In FL Studio choose **Options > Manage plugins > Find installed plugins**, then load **ISRAVN Hardstyle V.1**.

**Note:** A GitHub Actions run is required; the source archive is NOT a compiled VST3. The project has not been validated on a Windows build runner yet, so build fixes may be required. GitHub Actions usage and artifact availability depend on your GitHub account/repository settings. Do not run unknown scripts without reviewing them.
