# Run in PowerShell from the extracted build ZIP directory.
$ErrorActionPreference = 'Stop'
$bundle = Get-ChildItem -Path $PSScriptRoot -Directory -Filter '*.vst3' | Select-Object -First 1
if (-not $bundle) { throw 'Could not find .vst3 folder next to this script.' }
$destination = Join-Path $env:COMMONPROGRAMFILES 'VST3'
New-Item -ItemType Directory -Path $destination -Force | Out-Null
Copy-Item -LiteralPath $bundle.FullName -Destination $destination -Recurse -Force
Write-Host "Installed $($bundle.Name) to $destination" -ForegroundColor Cyan
Write-Host 'In FL Studio: Options > Manage plugins > Find installed plugins.'
