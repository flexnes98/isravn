#pragma once
#include "PluginProcessor.h"

class IsravnHardstyleV1AudioProcessorEditor : public juce::AudioProcessorEditor
{
public:
    explicit IsravnHardstyleV1AudioProcessorEditor(IsravnHardstyleV1AudioProcessor&);
    void paint(juce::Graphics&) override;
    void resized() override;
private:
    IsravnHardstyleV1AudioProcessor& processor;
    juce::TextEditor prompt;
    juce::TextButton generate {"GENERATE PRESET"};
    juce::Label status;
    int variation = 0;
    std::vector<std::unique_ptr<juce::Slider>> sliders;
    std::vector<std::unique_ptr<juce::Label>> labels;
    std::vector<std::unique_ptr<juce::AudioProcessorValueTreeState::SliderAttachment>> attachments;
    const std::vector<juce::String> ids {"unison", "detune", "mix", "cutoff", "drive", "pitch", "pitchdecay", "attack", "decay", "sustain", "release", "delay", "reverb", "output"};
    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR(IsravnHardstyleV1AudioProcessorEditor)
};
