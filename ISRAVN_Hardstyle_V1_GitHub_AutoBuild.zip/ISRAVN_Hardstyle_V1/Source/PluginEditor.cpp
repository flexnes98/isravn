#include "PluginEditor.h"

IsravnHardstyleV1AudioProcessorEditor::IsravnHardstyleV1AudioProcessorEditor(IsravnHardstyleV1AudioProcessor& p)
    : AudioProcessorEditor(&p), processor(p)
{
    setSize(940, 580);
    prompt.setMultiLine(false);
    prompt.setText("Dark aggressive rawstyle screech");
    prompt.setColour(juce::TextEditor::backgroundColourId, juce::Colour(0xff102634));
    prompt.setColour(juce::TextEditor::textColourId, juce::Colours::white);
    prompt.setColour(juce::TextEditor::outlineColourId, juce::Colour(0xff32627a));
    addAndMakeVisible(prompt);
    generate.setColour(juce::TextButton::buttonColourId, juce::Colour(0xff00a6c8));
    generate.setColour(juce::TextButton::textColourOffId, juce::Colours::white);
    addAndMakeVisible(generate);
    generate.onClick = [this]
    {
        processor.generatePreset(prompt.getText(), variation++);
        status.setText("Preset generated locally - edit controls or play MIDI", juce::dontSendNotification);
    };
    status.setText("OFFLINE GENERATOR  |  MIDI-READY  |  VST3", juce::dontSendNotification);
    status.setColour(juce::Label::textColourId, juce::Colour(0xffa0c9d7));
    addAndMakeVisible(status);
    for (const auto& id : ids)
    {
        auto slider = std::make_unique<juce::Slider>();
        slider->setSliderStyle(juce::Slider::RotaryHorizontalVerticalDrag);
        slider->setTextBoxStyle(juce::Slider::TextBoxBelow, false, 76, 18);
        slider->setColour(juce::Slider::rotarySliderFillColourId, juce::Colour(0xff54e4ff));
        slider->setColour(juce::Slider::rotarySliderOutlineColourId, juce::Colour(0xff234656));
        slider->setColour(juce::Slider::thumbColourId, juce::Colours::white);
        slider->setColour(juce::Slider::textBoxTextColourId, juce::Colours::white);
        slider->setColour(juce::Slider::textBoxOutlineColourId, juce::Colours::transparentBlack);
        addAndMakeVisible(*slider);
        auto label = std::make_unique<juce::Label>();
        label->setText(id.toUpperCase(), juce::dontSendNotification);
        label->setJustificationType(juce::Justification::centred);
        label->setColour(juce::Label::textColourId, juce::Colour(0xffc7e8f0));
        addAndMakeVisible(*label);
        attachments.push_back(std::make_unique<juce::AudioProcessorValueTreeState::SliderAttachment>(processor.apvts, id, *slider));
        sliders.push_back(std::move(slider));
        labels.push_back(std::move(label));
    }
}
void IsravnHardstyleV1AudioProcessorEditor::paint(juce::Graphics& g)
{
    g.fillAll(juce::Colour(0xff07131e));
    g.setColour(juce::Colour(0xff54e4ff));
    g.fillRect(0, 0, getWidth(), 5);
    g.setColour(juce::Colour(0x1836c9ee));
    for (int x = 0; x < getWidth(); x += 42) g.drawVerticalLine(x, 0.0f, (float)getHeight());
    for (int y = 0; y < getHeight(); y += 42) g.drawHorizontalLine(y, 0.0f, (float)getWidth());
    g.setColour(juce::Colours::white);
    g.setFont(juce::Font(juce::FontOptions(31.0f, juce::Font::bold)));
    g.drawText("ISRAVN", 28, 20, 550, 45, juce::Justification::centredLeft);
    g.setColour(juce::Colour(0xffb7f4ff));
    g.drawLine(770.0f, 36.0f, 815.0f, 78.0f, 2.0f);
    g.drawLine(815.0f, 36.0f, 770.0f, 78.0f, 2.0f);
    g.drawLine(792.5f, 26.0f, 792.5f, 88.0f, 2.0f);
    g.setColour(juce::Colour(0xff54e4ff));
    g.setFont(juce::Font(juce::FontOptions(14.0f, juce::Font::bold)));
    g.drawText("HARDSTYLE V.1  /  FROST ENGINE", 31, 65, 430, 24, juce::Justification::centredLeft);
    g.setColour(juce::Colour(0xff102431));
    g.fillRoundedRectangle(18.0f, 190.0f, (float)getWidth()-36.0f, 365.0f, 15.0f);
    g.setColour(juce::Colour(0xff7eb8cc));
    g.setFont(juce::Font(juce::FontOptions(13.0f)));
    g.drawText("SYNTH ENGINE  /  ENVELOPES  /  FX", 34, 196, 600, 24, juce::Justification::centredLeft);
}
void IsravnHardstyleV1AudioProcessorEditor::resized()
{
    prompt.setBounds(28, 110, 665, 40);
    generate.setBounds(706, 110, 205, 40);
    status.setBounds(28, 157, 850, 26);
    const int cols = 7;
    const int cellW = 126;
    for (size_t i = 0; i < sliders.size(); ++i)
    {
        const int col = (int)i % cols;
        const int row = (int)i / cols;
        const int x = 29 + col * cellW;
        const int y = 235 + row * 153;
        labels[i]->setBounds(x, y, 120, 24);
        sliders[i]->setBounds(x + 8, y + 25, 104, 110);
    }
}
juce::AudioProcessorEditor* IsravnHardstyleV1AudioProcessor::createEditor()
{
    return new IsravnHardstyleV1AudioProcessorEditor(*this);
}
