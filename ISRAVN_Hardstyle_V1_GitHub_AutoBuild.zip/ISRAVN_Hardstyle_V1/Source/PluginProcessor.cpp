#include "PluginProcessor.h"
#include "PluginEditor.h"
#include <cmath>

void HardVoice::setRate(double rate)
{
    sampleRateHz = rate;
    envelope.setSampleRate(rate);
}
void HardVoice::startNote(int midi, float velocity, juce::SynthesiserSound*, int)
{
    baseFrequency = juce::MidiMessage::getMidiNoteInHertz(midi);
    velocityGain = velocity;
    elapsed = 0.0;
    lp = 0.0f;
    for (auto& p : phases) p = 0.0;
    envelope.noteOn();
}
void HardVoice::stopNote(float, bool allowTailOff)
{
    envelope.noteOff();
    if (!allowTailOff) { envelope.reset(); clearCurrentNote(); }
}
void HardVoice::renderNextBlock(juce::AudioBuffer<float>& output, int start, int count)
{
    if (!isVoiceActive()) return;
    juce::ADSR::Parameters env;
    env.attack = param("attack"); env.decay = param("decay");
    env.sustain = param("sustain"); env.release = param("release");
    envelope.setParameters(env);
    const int voices = juce::jlimit(1, 7, (int)std::round(param("unison")));
    const double detune = param("detune") * 0.45;
    const double cutoff = param("cutoff");
    const float alpha = (float)(1.0 - std::exp(-2.0 * juce::MathConstants<double>::pi * cutoff / sampleRateHz));
    const float drive = param("drive");
    const double pitchAmount = param("pitch") * 12.0;
    const double pitchDecay = param("pitchdecay");
    const float oscMix = param("mix");
    for (int n = 0; n < count; ++n)
    {
        if (!envelope.isActive()) { clearCurrentNote(); break; }
        const double bend = pitchAmount * std::exp(-elapsed / juce::jmax(0.005, pitchDecay));
        const double freq = baseFrequency * std::pow(2.0, bend / 12.0);
        float sample = 0.0f;
        for (int v = 0; v < voices; ++v)
        {
            const double offset = voices == 1 ? 0.0 : (2.0 * v / (voices - 1) - 1.0);
            phases[v] += freq * std::pow(2.0, offset * detune / 12.0) / sampleRateHz;
            phases[v] -= std::floor(phases[v]);
            const float saw = (float)(2.0 * phases[v] - 1.0);
            const float square = phases[v] < 0.5 ? 1.0f : -1.0f;
            sample += saw * (1.0f - oscMix) + square * oscMix;
        }
        sample /= std::sqrt((float)voices);
        lp += alpha * (sample - lp);
        const float saturated = std::tanh(lp * (1.0f + drive * 24.0f));
        const float amp = envelope.getNextSample() * velocityGain * 0.17f;
        for (int ch = 0; ch < output.getNumChannels(); ++ch)
            output.addSample(ch, start + n, saturated * amp);
        elapsed += 1.0 / sampleRateHz;
    }
}

class HardSound : public juce::SynthesiserSound
{
public:
    bool appliesToNote(int) override { return true; }
    bool appliesToChannel(int) override { return true; }
};

static juce::AudioProcessorValueTreeState::ParameterLayout layout()
{
    juce::AudioProcessorValueTreeState::ParameterLayout p;
    auto add = [&](const char* id, const char* name, float lo, float hi, float def, float step)
    {
        p.add(std::make_unique<juce::AudioParameterFloat>(juce::ParameterID{id, 1}, name,
            juce::NormalisableRange<float>(lo, hi, step), def));
    };
    add("attack", "Attack", 0.001f, 2.0f, 0.008f, 0.001f);
    add("decay", "Decay", 0.01f, 3.0f, 0.35f, 0.001f);
    add("sustain", "Sustain", 0.0f, 1.0f, 0.8f, 0.001f);
    add("release", "Release", 0.01f, 4.0f, 0.22f, 0.001f);
    add("unison", "Unison", 1.0f, 7.0f, 5.0f, 1.0f);
    add("detune", "Detune", 0.0f, 1.0f, 0.32f, 0.001f);
    add("mix", "Square Mix", 0.0f, 1.0f, 0.0f, 0.001f);
    add("cutoff", "Cutoff Hz", 100.0f, 18000.0f, 9000.0f, 1.0f);
    add("drive", "Distortion", 0.0f, 1.0f, 0.35f, 0.001f);
    add("pitch", "Pitch Envelope", -1.0f, 1.0f, 0.0f, 0.001f);
    add("pitchdecay", "Pitch Decay", 0.005f, 1.0f, 0.08f, 0.001f);
    add("delay", "Delay Mix", 0.0f, 0.7f, 0.16f, 0.001f);
    add("reverb", "Reverb Mix", 0.0f, 0.8f, 0.20f, 0.001f);
    add("output", "Output Gain", 0.0f, 1.5f, 0.65f, 0.001f);
    return p;
}
juce::AudioProcessorValueTreeState::ParameterLayout IsravnHardstyleV1AudioProcessor::makeLayout() { return layout(); }
IsravnHardstyleV1AudioProcessor::IsravnHardstyleV1AudioProcessor()
    : AudioProcessor(BusesProperties().withOutput("Output", juce::AudioChannelSet::stereo(), true)),
      apvts(*this, nullptr, "PARAMETERS", makeLayout())
{
    synth.addSound(new HardSound());
    for (int i = 0; i < 12; ++i) synth.addVoice(new HardVoice(apvts));
}
bool IsravnHardstyleV1AudioProcessor::isBusesLayoutSupported(const BusesLayout& l) const
{
    return l.getMainOutputChannelSet() == juce::AudioChannelSet::stereo();
}
void IsravnHardstyleV1AudioProcessor::prepareToPlay(double sr, int)
{
    currentSampleRate = sr;
    synth.setCurrentPlaybackSampleRate(sr);
    for (int i = 0; i < synth.getNumVoices(); ++i)
        if (auto* v = dynamic_cast<HardVoice*>(synth.getVoice(i))) v->setRate(sr);
    delayBuffer.setSize(2, (int)(sr * 2.0) + 1);
    delayBuffer.clear(); delayWrite = 0;
    reverb.reset(); reverb.setSampleRate(sr);
}
void IsravnHardstyleV1AudioProcessor::processBlock(juce::AudioBuffer<float>& buffer, juce::MidiBuffer& midi)
{
    juce::ScopedNoDenormals noDenormals;
    buffer.clear();
    synth.renderNextBlock(buffer, midi, 0, buffer.getNumSamples());
    const float wet = apvts.getRawParameterValue("delay")->load();
    const int length = delayBuffer.getNumSamples();
    const int offset = juce::jlimit(1, length - 1, (int)(currentSampleRate * 0.375));
    for (int n = 0; n < buffer.getNumSamples(); ++n)
    {
        const int read = (delayWrite - offset + length) % length;
        for (int ch = 0; ch < 2; ++ch)
        {
            const float dry = buffer.getSample(ch, n);
            const float delayed = delayBuffer.getSample(ch, read);
            buffer.setSample(ch, n, dry + wet * delayed);
            delayBuffer.setSample(ch, delayWrite, dry + delayed * 0.35f);
        }
        delayWrite = (delayWrite + 1) % length;
    }
    juce::Reverb::Parameters rp;
    rp.roomSize = 0.65f; rp.damping = 0.45f; rp.width = 1.0f;
    rp.wetLevel = apvts.getRawParameterValue("reverb")->load();
    rp.dryLevel = 1.0f - rp.wetLevel * 0.35f;
    reverb.setParameters(rp);
    reverb.processStereo(buffer.getWritePointer(0), buffer.getWritePointer(1), buffer.getNumSamples());
    buffer.applyGain(apvts.getRawParameterValue("output")->load());
}
void IsravnHardstyleV1AudioProcessor::getStateInformation(juce::MemoryBlock& block)
{
    if (auto xml = apvts.copyState().createXml()) copyXmlToBinary(*xml, block);
}
void IsravnHardstyleV1AudioProcessor::setStateInformation(const void* data, int bytes)
{
    if (auto xml = getXmlFromBinary(data, bytes))
        if (xml->hasTagName(apvts.state.getType()))
            apvts.replaceState(juce::ValueTree::fromXml(*xml));
}
void IsravnHardstyleV1AudioProcessor::generatePreset(const juce::String& prompt, int variation)
{
    // Deterministic offline prompt-to-parameter generator; NOT a trained AI model.
    const auto s = prompt.toLowerCase();
    const bool raw = s.contains("raw") || s.contains("screech") || s.contains("aggressive") || s.contains("zaag");
    const bool euphoric = s.contains("euphoric") || s.contains("melodic") || s.contains("anthem") || s.contains("uplifting");
    const bool bass = s.contains("bass") || s.contains("kick") || s.contains("punch");
    const bool dark = s.contains("dark") || s.contains("industrial") || s.contains("metallic");
    juce::Random rng((juce::int64)prompt.hashCode64() + (juce::int64)variation * 7919);
    auto set = [&](const char* id, float value)
    {
        if (auto* p = apvts.getParameter(id))
        {
            const auto& range = apvts.getParameterRange(id);
            p->beginChangeGesture();
            p->setValueNotifyingHost(range.convertTo0to1(value));
            p->endChangeGesture();
        }
    };
    auto jitter = [&]() { return rng.nextFloat() * 0.18f - 0.09f; };
    set("unison", bass ? 1.0f : (euphoric ? 7.0f : 4.0f));
    set("detune", juce::jlimit(0.0f, 1.0f, (euphoric ? 0.52f : 0.22f) + jitter()));
    set("mix", juce::jlimit(0.0f, 1.0f, (raw ? 0.7f : 0.08f) + jitter()));
    set("cutoff", juce::jlimit(100.0f, 18000.0f, (bass ? 1800.0f : dark ? 3800.0f : 11000.0f) * (1.0f + jitter())));
    set("drive", juce::jlimit(0.0f, 1.0f, (raw ? 0.88f : bass ? 0.75f : 0.28f) + jitter()));
    set("pitch", bass ? 0.85f : raw ? 0.22f : 0.0f);
    set("pitchdecay", bass ? 0.045f : 0.12f);
    set("attack", bass ? 0.001f : euphoric ? 0.018f : 0.004f);
    set("decay", bass ? 0.16f : 0.35f);
    set("sustain", bass ? 0.15f : 0.83f);
    set("release", bass ? 0.08f : euphoric ? 0.48f : 0.16f);
    set("delay", bass ? 0.0f : euphoric ? 0.28f : 0.1f);
    set("reverb", bass ? 0.02f : euphoric ? 0.36f : 0.12f);
    set("output", raw ? 0.43f : 0.65f);
}

juce::AudioProcessor* JUCE_CALLTYPE createPluginFilter() { return new IsravnHardstyleV1AudioProcessor(); }
