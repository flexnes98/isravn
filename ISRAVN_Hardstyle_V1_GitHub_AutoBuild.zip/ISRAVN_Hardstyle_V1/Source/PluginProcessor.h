#pragma once
#include <JuceHeader.h>

class HardVoice : public juce::SynthesiserVoice
{
public:
    explicit HardVoice(juce::AudioProcessorValueTreeState& state) : apvts(state) {}
    bool canPlaySound(juce::SynthesiserSound* s) override { return dynamic_cast<juce::SynthesiserSound*>(s) != nullptr; }
    void startNote(int midiNoteNumber, float velocity, juce::SynthesiserSound*, int) override;
    void stopNote(float, bool allowTailOff) override;
    void pitchWheelMoved(int) override {}
    void controllerMoved(int, int) override {}
    void renderNextBlock(juce::AudioBuffer<float>&, int, int) override;
    void setRate(double rate);
private:
    float param(const char* id) const { return apvts.getRawParameterValue(id)->load(); }
    juce::AudioProcessorValueTreeState& apvts;
    juce::ADSR envelope;
    double sampleRateHz = 44100.0, baseFrequency = 440.0, elapsed = 0.0;
    double phases[7]{};
    float lp = 0.0f, velocityGain = 0.0f;
};

class IsravnHardstyleV1AudioProcessor : public juce::AudioProcessor
{
public:
    IsravnHardstyleV1AudioProcessor();
    ~IsravnHardstyleV1AudioProcessor() override = default;
    void prepareToPlay(double, int) override;
    void releaseResources() override {}
    bool isBusesLayoutSupported(const BusesLayout&) const override;
    void processBlock(juce::AudioBuffer<float>&, juce::MidiBuffer&) override;
    juce::AudioProcessorEditor* createEditor() override;
    bool hasEditor() const override { return true; }
    const juce::String getName() const override { return "ISRAVN Hardstyle V.1"; }
    bool acceptsMidi() const override { return true; }
    bool producesMidi() const override { return false; }
    bool isMidiEffect() const override { return false; }
    double getTailLengthSeconds() const override { return 4.0; }
    int getNumPrograms() override { return 1; }
    int getCurrentProgram() override { return 0; }
    void setCurrentProgram(int) override {}
    const juce::String getProgramName(int) override { return "Default"; }
    void changeProgramName(int, const juce::String&) override {}
    void getStateInformation(juce::MemoryBlock&) override;
    void setStateInformation(const void*, int) override;
    static juce::AudioProcessorValueTreeState::ParameterLayout makeLayout();
    juce::AudioProcessorValueTreeState apvts;
    void generatePreset(const juce::String& prompt, int variation);
private:
    juce::Synthesiser synth;
    juce::Reverb reverb;
    juce::AudioBuffer<float> delayBuffer;
    int delayWrite = 0;
    double currentSampleRate = 44100.0;
    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR(IsravnHardstyleV1AudioProcessor)
};
